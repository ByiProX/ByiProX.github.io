---
title: HTML里引入CSS的四种方式
date: 2018-04-09 22:42:46
tags:
  - Frontend
categories:
  - Frontend
---
1. 行内式：也称内联式，在标记的style属性中设定CSS样式。这种方式没有体现出CSS的优势；

2. 嵌入式：将CSS样式集中写在网页的<head></head>标签对的<style></style>标签对中；

3. 链接式：跟第4个的导入式都称外部式或者外联式，使用link引用外部CSS文件；

4. 导入式：使用@import引用外部CSS文件；
