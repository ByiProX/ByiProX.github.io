---
title: java平台结构
date: 2018-09-04 10:09:58
tags:
  - Java
categories:
  - Java
---

![java平台结构](https://upload-images.jianshu.io/upload_images/2952111-f55b3fb6121e758c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
