---
title: Java类属性和方法的可见性
date: 2018-09-06 10:33:20
tags:
  - Java
categories:
  - Java
---

![Screen Shot 2018-09-06 at 10.31.39.png](https://upload-images.jianshu.io/upload_images/2952111-2df8d57552a82ea7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
