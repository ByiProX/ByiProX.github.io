---
title: Java 关键字this和super
date: 2018-09-07 10:32:12
tags:
  - Java
categories:
  - Java
---
关键字this有两个用途：
1. 引用隐式参数
2. 调用该类其他的构造器

关键字super也有两个用途：
1. 调用超类的方法
2. 调用超类的构造器
