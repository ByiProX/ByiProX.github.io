---
title: Mac下打开swf文件
date: 2018-05-11 13:23:17
tags:
  - Linux/Mac OS
categories:
  - Linux/Mac OS
---

编辑一个HTML文件，写入如下代码：
```HTML
<html>
    <body>
        <embed src="your-file-name-of-swf.swf" width="500" height="500"></embed>
    </body>
</html>
```
然后使用chrome打开即可，在chrome下使用打印功能，可以将swf文件保存为pdf格式。
<!-- more -->
