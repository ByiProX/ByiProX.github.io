---
title: Linux Bash 默认的组合键汇总
date: 2018-09-05 13:44:51
tags:
  - Linux/Mac OS
categories:
  - Linux/Mac OS
---
| 案件组合           | 执行结果     |
| :-----:           | :-----:     |
|Ctrl + C           |终止目前命令   |
|Ctrl + D           |     输入结束（EOF）,例如邮件结束的时候    |
|Ctrl + M           | 就是Enter  |
|Ctrl + S           |暂停屏幕的输出 |
|Ctrl + Q           |恢复屏幕输出|
|Ctrl + U           |在提示符下，将整行命令删除|
|Ctrl + Z           |暂停目前的命令|
